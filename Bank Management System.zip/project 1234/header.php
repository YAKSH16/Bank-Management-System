<html>
<title>Online Banking System</title>
<head>
<link rel="stylesheet" type="text/css" href="css/header.css">
</head>
<body>

        
        <div class="header_main">
		<div class="navBar">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="index.php#aboutus">About Us</a></li>
                <li><a href="index.php#contactus">Contact Us</a></li>
				<li><a href="staff_login.php"> Staff Login</li> </a>
				<li><a href="add_staff.php"> Staff Register</li> </a>
				
			
			</ul>
		</div>
	 <a href="index.php"><div class="logo-name">
			<div class="logo">
             <img class="logo_img" src="img/chase.jpg">
			</div>
			
			<div class="name">
				<h5> Apna Bank Pvt Ltd.</h5></a><br>
				
			</div>
        </div>
        </div>
</body>
</html>