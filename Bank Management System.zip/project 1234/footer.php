<link rel="stylesheet" type="text/css" href="css/footer.css">
<footer>
<div class="container">
<div class="follow_us">
    <label>Follow Us</label>
    <ul>
        <li><a href="https://www.facebook.com/">Facebook</a></li>
        <li><a href="https://twitter.com/">Twitter</a></li>
        <li><a href="https://www.instagram.com/">Instagram</a></li>
    
    </ul>
    </div>
    <div class="contact" id="contactus">
        <label>Contact Us</label>
        <ul>
            <p>Apna Bank Pvt Ltd</p><p>SG Highway Ahmedabad 234565</p>
            <p>Tel : 022-24105261</p>
            <p>Email: apnabank12@gmail.com</p>
            
        </ul>
    </div>
        <div class="links">
            <label>Important Links</label>
            <ul>    
            <li><a href="index.php#aboutus" target="_blank">About Us</a></li>
            <li><a href="">Loan</a></li>
            <li><a href="">Calculator</a></li> 
            </ul><br>
    </div>

    
    
    
    </div>
    <div class="copyright">
        <span>Copyright &copy; 2023-24 Online Banking System. All rights reserved.</span>
    </div>
    
    

</footer>